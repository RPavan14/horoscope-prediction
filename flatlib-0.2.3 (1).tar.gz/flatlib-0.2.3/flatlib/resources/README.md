# flatlib resources

Includes resources for the flatlib library